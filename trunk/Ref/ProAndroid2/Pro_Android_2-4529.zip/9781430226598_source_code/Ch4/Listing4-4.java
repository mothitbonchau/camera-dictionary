      setContentView(R.layout.main);

      TextView nameValue = (TextView)findViewById(R.id.nameValueText);
      nameValue.setText("John Doe");
      TextView addrValue = (TextView)findViewById(R.id.addrValueText);
      addrValue.setText("911 Hollywood Blvd.");

