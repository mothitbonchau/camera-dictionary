TextView tv =(TextView)this.findViewById(R.id.cctvex);
tv.setText("Please visit my website, http://www.sayedhashimi.com
or email me at sayed@sayedhashimi.com.");
Linkify.addLinks(tv, Linkify.ALL);

