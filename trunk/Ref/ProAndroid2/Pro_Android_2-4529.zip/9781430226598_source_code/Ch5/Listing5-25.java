//get the dialog
AlertDialog ad = builder.create();
ad.show();

//return the prompt
return pl.getPromptReply();


