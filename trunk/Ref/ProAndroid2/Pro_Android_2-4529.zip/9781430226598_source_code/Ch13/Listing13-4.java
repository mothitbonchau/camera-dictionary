public class BDayWidgetProvider extends AppWidgetProvider
{
   public void onUpdate(Context context,
                  AppWidgetManager appWidgetManager,
                  int[] appWidgetIds){}
                  
   public void onDeleted(Context context, int[] appWidgetIds){}
   public void onEnabled(Context context){}
   public void onDisabled(Context context) {}
}
