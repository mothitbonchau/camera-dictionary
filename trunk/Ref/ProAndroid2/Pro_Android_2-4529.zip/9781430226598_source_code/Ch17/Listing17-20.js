var MY_NAME_SPACE = function() {
   return {
         method_1 : function() {
         // do stuff here
      },
         method_2 : function() {
         // do stuff here
      }
   };
}();
