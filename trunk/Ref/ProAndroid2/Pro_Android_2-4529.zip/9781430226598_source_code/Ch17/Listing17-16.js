function paragraphMouseover()
{
	$("p").mouseover(function () {
		$(this).css("color","red");
	});
}
