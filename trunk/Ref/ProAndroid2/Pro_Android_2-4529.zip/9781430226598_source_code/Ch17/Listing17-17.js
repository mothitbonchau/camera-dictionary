var itemArray = [
   {name: "Social", value: "12345678"},
   {name: "cell1", value: "12345678"},
   {name: "cell2", value: "12345678"}
];
