var someobj = {field1:10,
            field2:"string",
            field3:{field1:10,field2:"string"));
