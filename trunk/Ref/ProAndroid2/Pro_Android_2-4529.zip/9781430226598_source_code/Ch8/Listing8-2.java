HttpGet method = new HttpGet("http://somehost/WS2/Upload.aspx?one=valueGoesHere");
client.execute(method);
