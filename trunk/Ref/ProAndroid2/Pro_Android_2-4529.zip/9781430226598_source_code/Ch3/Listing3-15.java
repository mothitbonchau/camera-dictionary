// Get a drawable
ColorDrawble redDrawable =
(ColorDrawable)
activity.getResources().getDrawable(R.drawable.red_rectnagle);

//Set it as a background to a text view
textView.setBackground(redDrawable);


