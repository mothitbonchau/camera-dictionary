float dimen = 
  activity.getResources().getDimension(R.dimen.mysize_in_pixels);


