int mainBackGroundColor
    = activity.getResources.getColor(R.color.main_back_ground_color);


