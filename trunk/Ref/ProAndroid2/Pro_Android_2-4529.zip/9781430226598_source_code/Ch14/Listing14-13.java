//filename: LocalSearchEnabledActivity.java
public class LocalSearchEnabledActivity extends Activity
{
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.local_search_enabled_activity);
      return;
   }
}
