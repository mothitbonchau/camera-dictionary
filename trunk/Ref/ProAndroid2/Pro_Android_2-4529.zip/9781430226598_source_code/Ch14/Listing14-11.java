//filename: SearchActivity.java
public class SearchActivity extends Activity
{
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.search_activity);
      return;
   }
}
