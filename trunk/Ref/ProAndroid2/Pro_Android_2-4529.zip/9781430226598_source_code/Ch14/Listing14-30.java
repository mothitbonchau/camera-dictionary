private static final String[] COLUMNS = {
   "_id", // must include this column
   SearchManager.SUGGEST_COLUMN_TEXT_1,
   SearchManager.SUGGEST_COLUMN_TEXT_2,
   SearchManager.SUGGEST_COLUMN_INTENT_DATA,
   SearchManager.SUGGEST_COLUMN_INTENT_ACTION,
   SearchManager.SUGGEST_COLUMN_SHORTCUT_ID,
   "call_column",
   "my_column"
};
