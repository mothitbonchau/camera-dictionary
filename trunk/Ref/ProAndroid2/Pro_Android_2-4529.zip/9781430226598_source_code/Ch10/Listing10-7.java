glViewport(0, // lower left "x" of the rectangle on the screen
   0,        // lower left "y" of the rectangle on the screen
   width,    // width of the rectangle on the screen
   height);  // height of the rectangle on the screen
