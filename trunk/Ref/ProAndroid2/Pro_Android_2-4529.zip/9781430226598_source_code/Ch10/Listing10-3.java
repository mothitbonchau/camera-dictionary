glVertexPointer(
   // Are we using (x,y) or (x,y,z) in each point
   3,
   // each value is a float value in the buffer
   GL10.GL_FLOAT,
   // Between two points there is no space
   0,
   // pointer to the start of the buffer
   mFVertexBuffer);


