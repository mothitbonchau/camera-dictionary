<menu xmlns:android="http://schemas.android.com/apk/res/android">
   <!-- This group uses the default category. -->
   <group android:id="@+id/menuGroup_Main">
      <item android:id="@+id/mid_OpenGL_SimpleTriangle"
      android:title="Simple Triangle" />

      <item android:id="@+id/mid_OpenGL_AnimatedTriangle15"
      android:title="Animated Triangle" />

      <item android:id="@+id/mid_rectangle"
      android:title="rectangle" />

      <item android:id="@+id/mid_square_polygon"
      android:title="square polygon" />

      <item android:id="@+id/mid_polygon"
      android:title="polygon" />

      <item android:id="@+id/mid_textured_square"
      android:title="textured square" />

      <item android:id="@+id/mid_textured_polygon"
      android:title="textured polygon" />

      <item android:id="@+id/mid_OpenGL_Current"
      android:title="Current" />

      <item android:id="@+id/menu_clear"
      android:title="clear" />
   </group>
</menu>
