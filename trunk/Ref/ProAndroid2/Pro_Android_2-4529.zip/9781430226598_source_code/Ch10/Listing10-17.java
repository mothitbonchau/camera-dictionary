<activity android:name=".AnimatedTriangleActivity"
   android:label="OpenGL Animated Test Harness"/>
