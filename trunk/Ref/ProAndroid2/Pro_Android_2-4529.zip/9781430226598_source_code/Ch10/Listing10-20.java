Intent intent = getIntent();
int mid = intent.getIntExtra("com.ai.menuid", R.id.mid_OpenGL_Current);
if (mid == R.id.MenuId_OpenGL15_Current)
{
   ....
}
