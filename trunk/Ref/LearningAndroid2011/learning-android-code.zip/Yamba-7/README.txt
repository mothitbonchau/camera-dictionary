Corresponds to Chapter 12 - Content Providers
