Corresponds to Chapter 11 - Broadcast Receivers
