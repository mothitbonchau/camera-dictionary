#include "com_marakana_FibLib.h" /* <1> */

/* Recursive Fibonacci Algorithm <2> */
jlong fibN(jlong n) {
  if(n<=0) return 0;
  if(n==1) return 1;
  return fibN(n-1) + fibN(n-2);
}

/* Iterative Fibonacci Algorithm <3> */
jlong fibNI(jlong n) {
  jlong previous = -1;
  jlong result = 1;
  jlong i=0;
  int sum=0;
  for (i = 0; i <= n; i++) {
    sum = result + previous;
    previous = result;
    result = sum;
  }
  return result;
}

/* Signature of the JNI method as generated in header file <4> */
JNIEXPORT jlong JNICALL Java_com_marakana_FibLib_fibN
  (JNIEnv *env, jclass clazz, jlong  n) {
  return fibN(n);
}
/* Signature of the JNI method as generated in header file <5> */
JNIEXPORT jlong JNICALL Java_com_marakana_FibLib_fibNI
  (JNIEnv *env, jclass clazz, jlong  n) {
  return fibNI(n);
}
