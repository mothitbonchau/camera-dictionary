package com.marakana;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Fibonacci extends Activity implements OnClickListener {
	TextView textResult;
	Button buttonGo;
	EditText editInput;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Find UI views
		editInput = (EditText) findViewById(R.id.editInput);
		textResult = (TextView) findViewById(R.id.textResult);
		buttonGo = (Button) findViewById(R.id.buttonGo);
		buttonGo.setOnClickListener(this);
	}

	public void onClick(View view) {

		int input = Integer.parseInt(editInput.getText().toString()); // <1>

		long start, stop;
		long result;
		String out = "";

		// Dalvik - Recursive
		start = System.currentTimeMillis(); // <2>
		result = FibLib.fibJ(input);  // <3>
		stop = System.currentTimeMillis();  // <4>
		out += String.format("Dalvik recursive: %d (%d msec)", result, stop
				- start);

		// Dalvik - Iterative
		start = System.nanoTime(); 
		result = FibLib.fibJI(input); // <5>
		stop = System.nanoTime();
		out += String.format("\nDalvik iterative: %d (%d nsec)", result, stop
				- start);

		// Native - Recursive
		start = System.currentTimeMillis();
		result = FibLib.fibN(input); // <6>
		stop = System.currentTimeMillis(); 
		out += String.format("\nNative recursive: %d (%d msec)", result, stop
				- start);

		// Native - Iterative
		start = System.nanoTime();
		result = FibLib.fibNI(input); // <7>
		stop = System.nanoTime();
		out += String.format("\nNative iterative: %d (%d nsec)", result, stop
				- start);

		textResult.setText(out); // <8>
	}
}