package com.manning.aip.dealdroid.xml;

import com.manning.aip.dealdroid.model.Section;

import java.util.ArrayList;

public interface DailyDealsFeedParser {
   ArrayList<Section> parse();
}
