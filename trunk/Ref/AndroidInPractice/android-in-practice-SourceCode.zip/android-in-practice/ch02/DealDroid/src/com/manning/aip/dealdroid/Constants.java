package com.manning.aip.dealdroid;

public class Constants {

   public static final String LOG_TAG = "DealDroid";
}
