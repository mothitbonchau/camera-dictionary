package com.manning.aip.mymoviesdatabase;

public final class Constants {

   public static final String LOG_TAG = "MyMovies";

   private Constants() {
   }
}
