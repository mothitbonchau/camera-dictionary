package com.manning.aip.brewmap;

public final class Constants {

   public static final String LOG_TAG = "BeerMap";
   
   private Constants() {      
   }
}
