package android_programmers_guide.AndroidLBS;


import android.os.Bundle;
import android.location.LocationManager;
import android.view.View;
import android.widget.TextView;
import android.content.Context;
import android.widget.Button;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.Point;
import com.google.android.maps.MapController;



public class AndroidLBS extends MapActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
        final MapView myMap = (MapView) findViewById(R.id.myMap);
        final MapController myMapController = myMap.getController();
        final Button zoomIn = (Button) findViewById(R.id.buttonZoomIn);
        zoomIn.setOnClickListener(new Button.OnClickListener() {
       	  public void onClick(View v){
       		  ZoomIn(myMap,myMapController);
       	  }});
        final Button zoomOut = (Button) findViewById(R.id.buttonZoomOut);
        zoomOut.setOnClickListener(new Button.OnClickListener() {
       	  public void onClick(View v){
       		  ZoomOut(myMap,myMapController);
       	  }});
        final Button gpsButton = (Button) findViewById(R.id.gpsButton);
       gpsButton.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  LoadProviders(myMap,myMapController);
      	  }});
       final Button viewMap = (Button) findViewById(R.id.buttonMapView);
       viewMap.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  ShowMap(myMap,myMapController);
      	  }});
       final Button viewSat = (Button) findViewById(R.id.buttonSatView);
       viewSat.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  ShowSat(myMap,myMapController);
      	  }});
             
    }

    public void LoadProviders(MapView mv, MapController mc){
    	TextView latText = (TextView) findViewById(R.id.latText);
    	TextView lngText = (TextView) findViewById(R.id.lngText);
    	LocationManager myManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    	Double latPoint = myManager.getCurrentLocation("gps").getLatitude()*1E6;
    	Double lngPoint = myManager.getCurrentLocation("gps").getLongitude()*1E6;
    	latText.setText(latPoint.toString());
    	lngText.setText(lngPoint.toString());
     	Point myLocation = new Point(latPoint.intValue(),lngPoint.intValue());
     	mc.centerMapTo(myLocation, false);
     	mc.zoomTo(9);
       mv = null;
    }
    public void ZoomIn(MapView mv, MapController mc){
    	if(mv.getZoomLevel()!=21){
    	mc.zoomTo(mv.getZoomLevel()+ 1);
    	}
    }
    public void ZoomOut(MapView mv, MapController mc){
    	if(mv.getZoomLevel()!=1){
        	mc.zoomTo(mv.getZoomLevel()- 1);
        	}
    }
    public void ShowMap(MapView mv, MapController mc){
    		if (mv.isSatellite()){
    			mv.toggleSatellite();
    		}
    }
    public void ShowSat(MapView mv, MapController mc){
		if (!mv.isSatellite()){
			mv.toggleSatellite();
		}
    }
    }


