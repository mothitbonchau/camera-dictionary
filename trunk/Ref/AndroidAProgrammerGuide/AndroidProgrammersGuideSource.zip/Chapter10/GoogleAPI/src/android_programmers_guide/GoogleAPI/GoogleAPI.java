package android_programmers_guide.GoogleAPI;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.provider.Im;
import android.graphics.Color;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ListAdapter;
import android.widget.Button;
import android.widget.SimpleCursorAdapter;
import com.google.android.gtalkservice.IGTalkSession;
import com.google.android.gtalkservice.IGTalkService;
import com.google.android.gtalkservice.GTalkServiceConstants;
import com.google.android.gtalkservice.IChatSession;

public class GoogleAPI extends Activity implements View.OnClickListener {
	 EditText messageText;
	 ListView messageList;
	 IGTalkSession myIGTalkSession;
	 EditText messageTo;
	 Button mSend;
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
    	myIGTalkSession = null;
        messageText = (EditText) findViewById(R.id.messageText);
        messageList = (ListView) findViewById(R.id.messageList);
        messageTo = (EditText) findViewById(R.id.messageTo);
        mSend = (Button) findViewById(R.id.btnSend);
        mSend.setOnClickListener(this);
        messageList.setBackgroundColor(Color.GRAY );
        
        this.bindService(new Intent().setComponent(GTalkServiceConstants.GTALK_SERVICE_COMPONENT), connection, 0); 
       
    }

     private ServiceConnection connection = new ServiceConnection() {
    	public void onServiceConnected(ComponentName name, IBinder service) { 
    		try { 
    		myIGTalkSession = IGTalkService.Stub.asInterface(service).getDefaultSession(); 
    		} catch (DeadObjectException e) { 
    			myIGTalkSession = null; 
    		} 
    		} 

    		public void onServiceDisconnected(ComponentName name) { 
    			myIGTalkSession = null; 
    		} 

    };


    public void onClick(View view) {

            Cursor cursor = managedQuery(Im.Messages.CONTENT_URI, null,
                    "contact=\'" + messageTo.getText().toString() + "\'", null, null);
            ListAdapter adapter = new SimpleCursorAdapter(this,
                    android.R.layout.simple_list_item_1, cursor, 
                    new String[]{Im.MessagesColumns.BODY},
                    new int[]{android.R.id.text1});
            this.messageList.setAdapter(adapter);

            String username = messageTo.getText().toString();

            try {
            	IChatSession chatSession;
            	chatSession = myIGTalkSession.createChatSession(username);
                chatSession.sendTextMessage(messageText.getText().toString());
            } catch (DeadObjectException ex) {
            	myIGTalkSession = null;
            }
        }

}
 