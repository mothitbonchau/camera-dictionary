package android_programmers_guide.HelloWorldImage;

import android.app.Activity;
import android.os.Bundle;

public class HelloWorldImage extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        /** Set content to main.xml */
        setContentView(R.layout.main);

    }
}