package android_programmers_guide.HelloWorldText;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class HelloWorldText extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
 super.onCreate(icicle);
        /**Hello World JFD */
        /**BEGIN           */
          /**Create TextView */
        TextView HelloWorldTextView = new TextView(this);
          /**Set text to Hello World */
        HelloWorldTextView.setText("Hello World!");
          /**Set ContentView to TextView */
        setContentView(HelloWorldTextView);
        /**END             */
    }
}