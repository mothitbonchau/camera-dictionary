package android_programmers_guide.AndroidPhoneDialer;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.net.Uri;
import android.widget.EditText;
import java.util.regex.*;
public class AndroidPhoneDialer extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main );
        final EditText phoneNumber = (EditText) findViewById(R.id.phoneNumber );
        final Button callButton = (Button) findViewById(R.id.callButton);
      callButton.setOnClickListener(new Button.OnClickListener() {
    	  public void onClick(View v){
    		  if (validatePhoneNumber(phoneNumber.getText().toString())){
        		  Intent CallIntent = new Intent(Intent.CALL_ACTION,Uri.parse("tel:" + phoneNumber.getText()));
        	      CallIntent.setLaunchFlags(Intent.NEW_TASK_LAUNCH );
        	      startActivity(CallIntent);
    		  }
    		  else{
        		  showAlert("Please enter a phone number in the X-XXX-XXX-XXXX format.",0, "Format Error", "Re-enter Number",false);
        		  phoneNumber.setText("");
        		  
    		  } 


    	  }
      });
   }
	  public boolean validatePhoneNumber(String number){
		  Pattern phoneNumber = Pattern.compile("(\\d-)?(\\d{3}-)?\\d{3}-\\d{4}");
		  Matcher matcher = phoneNumber.matcher(number);
		  return matcher.matches();
}

}