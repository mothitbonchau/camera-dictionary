package android_programmers_guide.AndroidViews;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Button;
import android.graphics.Color;

public class testCheckBox extends Activity {
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.checkbox);
        
        final CheckBox checkbox = (CheckBox) findViewById(R.id.testCheckBox);
        
        final Button changeButton = (Button) findViewById(R.id.layoutButton);
        changeButton.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption(checkbox); }
        });
        final Button changeButton2 = (Button) findViewById(R.id.textColorButton);
        changeButton2.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption2(checkbox);

      	  }
        });
    }
    public void changeOption(CheckBox checkbox){
    	if (checkbox.getHeight()==100){
    		checkbox.setHeight(30);
    	}
    	else{
    		checkbox.setHeight(100);
    	
    	}
    }
    public void changeOption2(CheckBox checkbox){
    	checkbox.setTextColor(Color.RED);
    }
}