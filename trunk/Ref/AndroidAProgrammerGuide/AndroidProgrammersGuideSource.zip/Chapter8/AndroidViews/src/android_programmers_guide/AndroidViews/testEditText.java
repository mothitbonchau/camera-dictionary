package android_programmers_guide.AndroidViews;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.graphics.Color;

public class testEditText extends Activity {
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.edittext);
        
        final EditText edittext = (EditText) findViewById(R.id.testEditText);
        
        final Button changeButton = (Button) findViewById(R.id.layoutButton);
        changeButton.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption(edittext); }
        });
        final Button changeButton2 = (Button) findViewById(R.id.textColorButton);
        changeButton2.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption2(edittext);

      	  }
        });
    }
    public void changeOption(EditText edittext){
    	if (edittext.getHeight()==100){
    		edittext.setHeight(30);
    	}
    	else{
    		edittext.setHeight(100);
    	
    	}
    }
    public void changeOption2(EditText edittext){
    	edittext.setTextColor(Color.RED);
    }
}