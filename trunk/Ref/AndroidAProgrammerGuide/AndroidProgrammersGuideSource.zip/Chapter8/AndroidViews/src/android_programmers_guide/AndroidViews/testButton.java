package android_programmers_guide.AndroidViews;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.graphics.Color;

public class testButton extends Activity {
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.button);
        
        final Button button = (Button) findViewById(R.id.testButton);
        
        final Button changeButton = (Button) findViewById(R.id.layoutButton);
        changeButton.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption(button); }
        });
        final Button changeButton2 = (Button) findViewById(R.id.textColorButton);
        changeButton2.setOnClickListener(new Button.OnClickListener() {
      	  public void onClick(View v){
      		  changeOption2(button);

      	  }
        });
    }
    public void changeOption(Button button){
    	if (button.getHeight()==100){
    		button.setHeight(30);
    	}
    	else{
    		button.setHeight(100);
    	
    	}
    }
    public void changeOption2(Button button){
    	button.setTextColor(Color.RED);
    }
}