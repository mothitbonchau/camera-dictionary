package android_programmers_guide.AndroidViews;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.content.Intent;


public class AndroidViews extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
       }

@Override
public boolean onCreateOptionsMenu(Menu menu) {
 super.onCreateOptionsMenu(menu);
 
 menu.add(0, 0, "AutoComplete");
 menu.add(0, 1, "Button");
 menu.add(0, 2, "CheckBox");
 menu.add(0, 3, "EditText");
 menu.add(0, 4, "RadioGroup");
 menu.add(0, 5, "Spinner");
 return true;
}

@Override
public boolean onOptionsItemSelected(Menu.Item item){
 switch (item.getId()) {
 case 0:
     showAutoComplete();
     return true;
 case 1:
     showButton();
     return true;
 case 2:
     showCheckBox();
	 return true;
 case 3:
	 showEditText();
	 return true;
 case 4:
	 showRadioGroup();
	 return true;
 case 5:
	 showSpinner();
	 return true;
 }
 return true;
}
public void showButton() {
	Intent showbutton = new Intent(this, testButton.class);
	startActivity(showbutton);
}
public void showAutoComplete(){
	Intent autocomplete = new Intent(this, AutoComplete.class);
	startActivity(autocomplete);
}
public void showCheckBox(){
	Intent checkbox = new Intent(this, testCheckBox.class);
	startActivity(checkbox);
 }
public void showEditText() {
	Intent edittext = new Intent(this, testEditText.class);
	startActivity(edittext);
 }
public void showRadioGroup(){
	Intent radiogroup = new Intent(this, testRadioGroup.class);
	startActivity(radiogroup);
}
public void showSpinner(){
	Intent spinner = new Intent(this, testSpinner.class);
	startActivity(spinner);
}

}