package example.telephony;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

public class telephonyExplorer extends Activity {
	ListenToPhoneState listener;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        call();
    }
    
	private void call() {
		try {
	    	Intent callIntent = new Intent(Intent.ACTION_CALL);
	    	callIntent.setData(Uri.parse("tel:9785551212"));
	    	startActivity(callIntent);
	    	
	    	TelephonyManager tManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
	    	listener = new ListenToPhoneState();
	    	tManager.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
		} catch (ActivityNotFoundException activityException) {
			Log.e("telephony-example", "Call failed", activityException);
		}
	}
	
	private class ListenToPhoneState extends PhoneStateListener {
		
		public void onCallStateChanged(int state, String incomingNumber) {
			Log.i("telephony-example", "State changed: " + stateName(state));
		}
		
		private String stateName(int state) {
			switch (state) {
			case TelephonyManager.CALL_STATE_IDLE: return "Idle";
			case TelephonyManager.CALL_STATE_OFFHOOK: return "Off hook";
			case TelephonyManager.CALL_STATE_RINGING: return "Ringing";
			}
			return Integer.toString(state);
		}
	}
}