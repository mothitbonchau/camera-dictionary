package com.msi.manning.chapter9.XMLDraw;

import android.app.Activity;
import android.os.Bundle;

public class XMLDraw extends Activity {

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.xmldrawable);
    }
}