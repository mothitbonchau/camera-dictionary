package com.msi.manning.chapter8.SMSNotifyExample2;

import android.app.Activity;
import android.os.Bundle;

public class SMSNotifyExampleActivity extends Activity {

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.main);
    }
}
