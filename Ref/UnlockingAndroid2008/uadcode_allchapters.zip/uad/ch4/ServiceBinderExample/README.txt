Unlocking Android - ServiceBinderExample
------------------------------------

Android project example that uses IPC 
through AIDL and Binder. 

Tested with Android 1.1 and 1.5.

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter4/trunk/ServiceBinderExample/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter4/trunk/ServiceBinderExample as an Eclipse project. 