package com.msi.manning.weather;

public class Constants {

    public static final String LOGTAG = "WeatherReporter";
    public static final String PREFS = "WR_PREFS";

    public static final String CLEARALERT = "com.msi.manning.weather.CLR";

}
