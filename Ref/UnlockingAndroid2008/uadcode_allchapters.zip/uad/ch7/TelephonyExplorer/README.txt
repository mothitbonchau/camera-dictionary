Unlocking Android - TelephonyExplorer
------------------------------------

Android application that exercises
many aspects of the telephony APIs
for the platform. 

Tested with 1.1 and 1.5.

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter7/trunk/TelephonyExplorer/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter7/trunk/TelephonyExplorer as an Eclipse project. 