package com.msi.manning.telephonyexplorer;

public class Constants {

    public static final String LOGTAG = "TelephonyExplorer";
}
