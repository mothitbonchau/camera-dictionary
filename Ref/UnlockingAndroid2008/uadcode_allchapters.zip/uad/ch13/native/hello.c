/*
	Unlocking Android, Chapter 13
	Author: Frank Ableson
*/

#include <stdio.h>


int main(int argc,char * argv[]) 
{

      printf("Hello, Android!\n");

		exit(0);
      //return 0;
}

