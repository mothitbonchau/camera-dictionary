Unlocking Android - ProviderExplorer
------------------------------------

Android project example that demonstrates
using a built in ContentProvider (for the phone contacts).

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter5/trunk/ProviderExplorer/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter5/trunk/ProviderExplorer as an Eclipse project. 