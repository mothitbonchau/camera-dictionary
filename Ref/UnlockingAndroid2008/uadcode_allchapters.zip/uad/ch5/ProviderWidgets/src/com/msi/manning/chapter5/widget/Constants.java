package com.msi.manning.chapter5.widget;

public class Constants {

    public static final String LOGTAG = "ProviderWidgets";

}
