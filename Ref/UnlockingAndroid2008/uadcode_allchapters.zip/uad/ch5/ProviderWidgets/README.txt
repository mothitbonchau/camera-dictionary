Unlocking Android - ProviderWidgets
------------------------------------

Android project example that demonstrates
creating a custom ContentProvider. 

This project also explores using a database on the 
Android platform and includes a SQLite database
that is created (via SQLiteOpenHelper) and used to 
store and retrieve data.

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter5/trunk/ProviderWidgets/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter5/trunk/ProviderWidgets as an Eclipse project. 