Unlocking Android - SharedPreferencesTester
------------------------------------

Android project that demonstrates working with the 
SharedPreferences object to handle state. 

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter5/trunk/SharedPreferencesTester/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter5/trunk/SharedPreferencesTester as an Eclipse project. 