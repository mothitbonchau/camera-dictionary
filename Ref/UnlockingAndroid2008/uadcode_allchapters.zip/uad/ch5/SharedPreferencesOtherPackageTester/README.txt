Unlocking Android - SharedPreferencesOtherPackageTester
------------------------------------

Android project that is used in conjunction with another (SharedPreferencesTester)
to demonstrates working with the SharedPreferences object 
across applications and processes. 

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter5/trunk/SharedPreferencesOtherPackageTester/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter5/trunk/SharedPreferencesOtherPackageTester as an Eclipse project. 