<?
require('db.php');
require('utils.php');
putTransaction($_GET['identifier'],$_GET['data'])
?>


