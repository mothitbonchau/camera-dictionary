<hr />
<center>MSI Wireless is a division of <a target="_blank" href="http://msiservices.com">MSI Services.</a><br>Check out <a target='_blank' href='http://manning.com/ableson'>Unlocking Android</a></center>
