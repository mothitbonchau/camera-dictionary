<?
require('header.php');
require('db.php');
require('utils.php');
showJob($_GET['jobid']);
require('footer.php');
?>


