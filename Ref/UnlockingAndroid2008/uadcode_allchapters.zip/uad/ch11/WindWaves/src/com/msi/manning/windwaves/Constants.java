package com.msi.manning.windwaves;

public class Constants {

    public static final String LOGTAG = "WindWaves";

}
