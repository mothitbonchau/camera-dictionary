Unlocking Android - GeocodeExample
------------------------------------

Android code example that walks through
geocoding and reverse geocoding using the
Geocoder class.

--------------------------------------

Checkout:
svn co http://unlocking-android.googlecode.com/svn/chapter11/trunk/GeocodeExample/


Eclipse:
Setup a SVN repository for the UAD code project (http://unlocking-android.googlecode.com/svn). 
Then checkout chapter11/trunk/GeocodeExample as an Eclipse project. 