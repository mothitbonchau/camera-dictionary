create table mytable (
   _id integer primary key autoincrement,
   name text,
   phone text ); 