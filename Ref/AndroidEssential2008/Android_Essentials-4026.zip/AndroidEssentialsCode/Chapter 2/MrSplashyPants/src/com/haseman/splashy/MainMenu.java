package com.haseman.splashy;

import android.app.Activity;
import android.os.Bundle;

public class MainMenu extends Activity
{
	public void onCreate(Bundle bun)
	{
		super.onCreate(bun);
		setContentView(R.layout.main);
		
	}
}
