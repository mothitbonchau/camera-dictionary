{\rtf1\ansi\ansicpg1252\cocoartf949\cocoasubrtf330
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww9000\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural

\f0\fs24 \cf0 Code for Android Essentials:\
\
Each chapter contains new revisions of the code.  Sometimes the same project will be used in more than one chapter.  Each chapter's folder contains the code in the state it should get to by the end of the chapter.\
\
Installing Requirements:\
Eclipse\
Android Plugin\
Android SDK\
\
Install notes:\
Import each chapters projects into your IDE (Eclipse meta data should be included as it's the IDE I used to create all the sample code)\
If you have all the required software referenced in Chapter 1 you should be able to build and run everything just fine.\
\
}